function git_pull
!git pull origin master
end 