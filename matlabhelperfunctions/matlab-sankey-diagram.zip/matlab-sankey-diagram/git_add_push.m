function git_add_push
!git add .
!git commit -m "add & push by Matlab"
!git push -u origin master
end 