# MATLAB sankey 桑基图

#### mathworks fileexchange 链接(引用格式)
Zhaoxu Liu / slandarer (2023). sankey plot (https://www.mathworks.com/matlabcentral/fileexchange/128679-sankey-plot), MATLAB Central File Exchange. 检索来源 2023/4/28.


#### 使用效果
![输入图片说明](gallery/demo8_1.png)

![输入图片说明](gallery/demo4_4.png)

![输入图片说明](gallery/demo7_1.png)

![输入图片说明](gallery/demo7_3.png)

![输入图片说明](gallery/demo5_5.png)

![输入图片说明](gallery/demo6.png)


